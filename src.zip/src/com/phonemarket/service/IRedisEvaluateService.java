package com.phonemarket.service;

public interface IRedisEvaluateService {
	void RefreshEvaluate(Integer goodsId);
}
